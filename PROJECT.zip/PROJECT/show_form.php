<!DOCTYPE HTML PUBLIC>
<HTML>
<head><Title>Form DATA</title>
<link rel="stylesheet" type="text/css" href="css/bill.css" />
<link rel="stylesheet" type="text/css" href="css/style1.css" />
<meta HTTP-EQUIV="REFRESH" CONTENT="120;URL=login.html" />
</head>
<body bgcolor="" >
<div class= "maindiv">
<div class= "form_div">
<div class ="title" style="width: 761px"; >

<h2><b> User Registration Detail</b></h2>


<?php

require_once('connection.php');

$temp=time();

$sql = "SELECT fname, lname, uname, gender, password, email, contact, address FROM members where show_time = '$temp'";
if(!isset($sql)){echo 'REQUEST TIME OUT';}
$result = mysqli_query($dbconnect,$sql) or die ('REQUEST TIME OUT');
$row = mysqli_fetch_assoc ($result);
{

echo "<div class='signup_result' ><table border='0' cellspacing='1px' cellpadding='10px' align='center'  width='100px'>";

	echo "<tr><td class='con' > First Name :</td>";
    echo "<td class='data' >". $row['fname']."</td></tr>";
	
   	echo "<tr><td class='con'  > Last Name :</td>";
    echo "<td class='data' >". $row['lname']."</td></tr>";

   	echo "<tr><td class='con' > Username :</td>";
    echo "<td class='data' >". $row['uname']."</td></tr>";
	
    echo "<tr><td class='con' > Gender :</td>";
    echo "<td class='data' >". $row['gender']."</td></tr>";
  
   	echo "<tr><td class='con' > Password :</td>";
    echo "<td class='data' >". $row['password']."</td></tr>";
	
	echo "<tr><td class='con' > E-mail :</td>";
    echo "<td class='data' >". $row['email']."</td></tr>";
	
   	echo "<tr><td class='con' > Contact :</td>";
    echo "<td class='data' >". $row['contact']."</td></tr>";
	
   	echo "<tr><td class='con' > Address :</td>";
    echo "<td class='data' > ". $row['address']."</td></tr>";
    

echo "</table></div>";
	
}
//mysql_free_result($result);	

?>


<tr><td class='input'  colspan=2 > <input class='submit' type="button" value="Close" onClick="document.location.href='login.html'" /></td></tr>

</div>
</div>
</div>
</body>
</html>