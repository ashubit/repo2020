<?php
require("connection.php");
//$current_date=date("d-m-Y");
if(isset($_POST['submit']))
{
	 $fname=$_POST['fname'];
	$lname=$_POST['lname'];
	$gender=$_POST['gender'];
	$email=$_POST['email'];
	$contact=$_POST['contact'];
	$address=$_POST['address'];
	$uname=$_POST['uname'];
	$password=$_POST['password'];	
	$show=time();
	//Insert query
	$result=mysqli_query($dbconnect, "INSERT INTO members (fname, lname, uname, password, gender, email, contact, address, activated, show_time) VALUES('$fname', '$lname', '$uname', '$password', '$gender', '$email',  '$contact', '$address', '1', '$show')");
	
	if($result)
	{
		header("Location:show_form.php?msg=Registration Successuly");
	}
	else
	{
		header("Location:index.php?err=Error in Registration");
	}
}
?>