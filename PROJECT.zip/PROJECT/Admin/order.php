

<?php

include_once("connection.php");

session_start();

if(!isset($_SESSION['Cust_id']))
{
  header("Location:index.php");
}

?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="images/order.ico">

    <title>Order</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/Bill.css">
    </head>
  <body role="document">

    <!-- Fixed navbar -->
    <nav class="navbar navbar-inverse navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
      <h1><a href="#">Pharma Store</a></h1>
      <h6 color="white">Medicine at you'r door Step</h6>
      </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li class="active"><a href="home.php">Home</a></li>
            <li><a href="profile.php">Profile</a></li>
            <li><a href="#">Place Order</a></li>
            <li><a href="logout.php">Logout</a></li>
       
           
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>
<div class="container" style="margin-top:100px; " >
<div class="col-lg-8">
<div class="panel panel-info" style="margin-right:auto;position: relative;left: 75px;">
<div class="panel-heading"><h3 class="panel-title">User Registration</h3></div>
<div class="panel-body">


<!-----SELECT MEDICINE-------------------------------------------------->
<fieldset>
<legend>SELECT MEDICINE</legend>
<div id=outtext >Select the Medicine and Submit</div>
<div id=select_med >

<?php

$query1 = mysqli_query($dbconnect,"SELECT Pro_id,Pro_name,Pro_price  FROM product_info "); 
echo '<form method="GET" action="order.php">';
echo '<select name="DROP">'; 

while ($row = mysqli_fetch_assoc($query1))
  {
  echo '<option value="'.$row['Pro_name'].''.$row['Pro_price'].'">'.$row['Pro_name'].' ₹'.$row['Pro_price'].'</option>';
  }

echo '</select>';  
echo '</div>';
echo '<div id="quantity" ">'; 
echo '<input type="text" name="quantity" placeholder="Quantity">';
echo '</div>';

echo '<div>';
echo '<input  style="position:absolute;left: 425px;top: 145px;" class="submit" type=submit name=submit>';
echo '</div>';

if(isset($_GET['DROP']) && isset($_GET['quantity']))
{
$dropint=substr($_GET['DROP'],-5);
$dropchar=substr($_GET['DROP'],0,strlen($_GET['DROP'])-5);//substr($var,0,strlen($var)-5);
$quantity = $_GET['quantity'];


$amount = $quantity * $dropint;

$query2=mysqli_query($dbconnect,"SELECT Pro_id FROM product_info where Pro_name = '$dropchar'");
$dbpro_id=mysqli_fetch_assoc($query2);
$var_dbpro_id=$dbpro_id['Pro_id'];//ID

$sql = mysqli_query($dbconnect,"INSERT INTO sales_report (Pro_id, Pro_name, Pro_quantity, Total_amount) VALUES('$var_dbpro_id', '$dropchar', '$quantity', '$amount')");

/*if($sql)
{
  echo 'Query2 Executer';
}
else
{
  echo 'invalid Query2';
}*/

//mysqli_free_result($query);

//FETCHING CUSTOMER_NAME AND ADDRESS FOR INSERTING INTO ORDER_db 

$sess1=$_SESSION['Cust_id'];

$query3=mysqli_query($dbconnect,"SELECT fname, address FROM members WHERE Cust_id='$sess1' ");
$dbname_addr=mysqli_fetch_assoc($query3);
$var_name=$dbname_addr['fname'];
$var_addr=$dbname_addr['address'];

echo '<br>';
//INSERTING VALUE INTO ORDER_db
echo '<br>';

$today=date("Y-m-d H:i:s");
$query4=mysqli_query($dbconnect,"INSERT INTO order_info (Pro_id, Cust_id, Cust_name,  Pro_name, Pro_price, Order_time, Pro_quantity, Delivery_add) VALUES('$var_dbpro_id', '$sess1', '$var_name', '$dropchar', '$dropint', '$today', '$quantity', '$var_addr' )" );



}//---------------------------------------------------





//PRINTING DETAIL ON PAGE 
$query5=mysqli_query($dbconnect,"SELECT Order_id, Cust_name,  Pro_name, Pro_price, Pro_quantity, Delivery_add FROM order_info WHERE Cust_id='$sess1' AND Order_time='$today' ");



echo '<br>';echo '<br>';

$dbdisplay=mysqli_fetch_assoc($query5);
$order_id=$dbdisplay['Order_id'];
$varname=$dbdisplay['Cust_name'];
$varpro=$dbdisplay['Pro_name'];
$varprice=$dbdisplay['Pro_price'];
$varquantity=$dbdisplay['Pro_quantity'];
$varaddr=$dbdisplay['Delivery_add'];


?>
<!--DISPLAYING BILL-------------------------------------------------->
<fieldset>
    <legend>BILL</legend>
    <table>
    <thead><tr><th>OrderNo.</th><th>Name</th><th>Medicine</th><th>Price</th><th>Quantity</th><th>Address</th></tr>
</thead>
<tbody><tr>
    <td><?php echo $order_id; ?></td>
    <td><?php echo $varname; ?></td>
    <td><?php echo $varpro; ?></td>
    <td><?php echo $varprice; ?></td>
    <td><?php echo $varquantity; ?></td>
    <td><?php echo $varaddr; ?></td></tr>
    </tbody>
    </table>

  </fieldset>


</div>
<!------------------------------------------------------------------------------- -->
<div class="panel-footer">
  
  

</div>
</div>
</div>
<div class="col-lg-4">
</div>
</div>
</div>


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="js/jquery-1.12.0.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>