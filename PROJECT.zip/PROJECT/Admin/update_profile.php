<?php
session_start();

if(!isset($_SESSION['Admin_id']))
{
	header("Location:index.php");
}

include_once("connection.php");

?>

<HTML>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title>Home</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
  </head>

  <body><nav class="navbar navbar-inverse navbar-fixed-top" style="
    height: 83px;
">
      <div class="container">
        <div class="navbar-header">
         
      <h1><a href="#">Pharma Store</a></h1>
      <h6 color="white">Medicine at you'r door Step</h6>
      </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li class="active"><a href="home.php">Home</a></li>
            <li><a href="profile.php">Profile</a></li>
            <li><a href="logout.php">Logout</a></li>
       
           
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>
  <div class="container">
    <div class="jumbotron" style="padding-bottom: 2px;">
      <h1 style="   margin-top: 36px; margin-bottom: 0px;">Profile Update <small>ByAshutosh</small></h1>
    </div>
  </div>
  <div class="container">
  <div class="row">
    <div class="col-md-3"></div>
    <div class="col-md-6">
      <div class="panel panel-primary">
      <div class="panel-heading">Updation Form</div>
    
    <div class=" panel-body">
          <table class="table table-hover">
          <tr>

 <form  method="GET" action=" <?php $_SERVER['PHP_SELF']; ?> ">  
<td>Name</td><td>
<input type="text" name="data1" placeholder="Name"></td><td>
<input type="submit"  VALUE="EDIT" > </td></tr>
</form> 

<?php 

$c_id=$_SESSION['Admin_id'];



if(isset($_GET['data1'])){
	$temp1 = $_GET['data1'];
mysqli_query($dbconnect,"UPDATE admin_info SET fname = '$temp1' WHERE Admin_id = '$c_id' "); }
?>
</div>

<!---------------------------------------------------------->

<tr>
 <form  method="GET" action=" <?php $_SERVER['PHP_SELF']; ?> ">            
  
<td>Password</td><td>
<input type="text" name="data4" placeholder="Pascode:123@znc"></td><td>
<input type="submit"  VALUE="EDIT" > </td></tr>
</form> 

<?php 
if(isset($_GET['data4'])){
	$temp4 = $_GET['data4'];
	mysqli_query($dbconnect,"UPDATE admin_info SET Admin_pwd = '$temp4' WHERE Admin_id = '$c_id' "); }
?>
</div>
<!---------------------------------------------------------->
 <tr>
 <form  method="GET" action=" <?php $_SERVER['PHP_SELF']; ?> "> 
<td>E-mail</td><td>

<input type="text" name="data5" placeholder="Mail:abc@ac.com"></td><td>
<input type="submit"  VALUE="EDIT" > </td></tr>
</form> 

<?php 
if(isset($_GET['data5'])){
	$temp5 = $_GET['data5'];
mysqli_query($dbconnect,"UPDATE admin_info SET Admin_email = '$temp5' WHERE Admin_id = '$c_id' ");} 
?>
</div>
<!---------------------------------------------------------->
 <tr>
 <form  method="GET" action=" <?php $_SERVER['PHP_SELF']; ?> "> 
<td>Contact No.</td><td>

<input type="text" name="data6" placeholder="Cont:98******68"></td><td>
<input type="submit"  VALUE="EDIT" ></td> </tr>
</form> 
</table>
<?php 
if(isset($_GET['data6'])){
	$temp6 = $_GET['data6'];
mysqli_query($dbconnect,"UPDATE admin_info SET Admin_phone = '$temp6' WHERE Admin_id = '$c_id' ");} 
?>
</div>
    </div>
    <div class="col-md-3"></div>
  </div>

  </div>

<!---------------------------------------------------------->

    <script src="js/jquery-1.12.0.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>

</HTML>