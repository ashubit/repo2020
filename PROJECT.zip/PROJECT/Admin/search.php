<?php
include_once("connection.php");

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title>Admin</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/Bill.css">

  </head>


  <body>
  <nav class="navbar navbar-inverse navbar-fixed-top" style="height:83px;">
      <div class="container">
        <div class="navbar-header">
         
      <h1><a href="#">Online_Med</a></h1>
      <h6 color="white">Medicine at you'r door Step</h6>
      </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li class="active"><a href="home.php">Home</a></li>
            <li><a href="profile.php">Profile</a></li>
            <li><a href="update.php">CRUD Operation</a></li>
            <li><a href="logout.php">Logout</a></li>
       
           
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>
  <div class="container">
  	<div class="jumbotron">
  		<h1>Stock Search <small></small></h1>
  	</div>
  </div>


  <div class="container">
  	<div class="row">
  		<div class="col-md-2"></div>
  		<div class="col-md-8">
  			<table class="table table-bordered">
			<thead>
  			<tr><th>Enter Medicine</th><th>
<form method="GET" action="search.php">
<input type="text" color="BLACK" name="search" spaceholder="Search here">
</th><th>

<input type="submit" name="sub" VALUE="[>>]">
</form>
</th></tr>
			
			<tr>
  				
  				<th>ID</th>
  				<th>Medicine Name</th>
				<th>Price</th>
  				
  				
  			</tr>
			</thead>
			<tbody>
	
<?php
//Collect
if(isset($_GET['sub']))
{
	$searchq = $_GET['search'];

	$searchq = preg_replace(("#[^0-9a-z]#i"),"",$searchq);
	$output="";
	$query = mysqli_query($dbconnect,"SELECT * FROM product_info WHERE Pro_id LIKE '%$searchq%' OR Pro_name LIKE '%$searchq%' ")  or die("could not Execute query");

$count = mysqli_num_rows($query);

if($count == 0){$output = 'There was no searh found';}
else{while($row1 = mysqli_fetch_assoc($query))
{

	$z=$row1['Pro_id'];
	$x=$row1['Pro_name'];
    $p=$row1['Pro_price'];
	echo '<tr><td>'.$z.'</td><td> '.$x.'</td><td>'.$p.'</td></tr>';
}
}
}
?>

</tbody>
</table>
	</div>
  		<div class="col-md-2"></div>
  	</div>
  </div>
    <script src="js/jquery-1.12.0.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>
