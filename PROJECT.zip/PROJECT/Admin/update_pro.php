<?php
//session_start();

include_once("connection.php");

if(isset($_SESSION['Admin_id']))
{
	header("Location:index.php");
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title>Home</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
  </head>

  <body><nav class="navbar navbar-inverse navbar-fixed-top" style="
    height: 83px;
">
      <div class="container">
        <div class="navbar-header">
         
      <h1><a href="#">Pharma Store</a></h1>
      <h6 color="white">Medicine at you'r door Step</h6>
      </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li class="active"><a href="home.php">Home</a></li>
            <li><a href="profile.php">Profile</a></li>
            <li><a href="search.php">Search</a></li>
            <li><a href="logout.php">Logout</a></li>
       
           
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>
  <div class="container">
  	<div class="jumbotron" style="padding-bottom: 2px;">
  		<h1 style="   margin-top: 36px; margin-bottom: 0px;">Medicine Stock <small>ByAshutosh</small></h1>
  	</div>
  </div>
  <div class="container">
  <div class="row">
  	<div class="col-md-3"></div>
  	<div class="col-md-6">
  		<div class="panel panel-primary">
  		<div class="panel-heading">Enter Medicine Details</div>
  	
  	<div class=" panel-body">
  		<form>
  			<table class="table table-hover">
  				<tr>
  					<td>Medicine Name</td>
  					<td><input type="text" class="form-control" name="pname" placeholder=" Enter Medicine name"></td>
  				</tr>
  				<tr>
  					<td>Product Category</td>
  					<td><input type="text" class="form-control" name="pcat" placeholder="Enter Category"></td>
  				</tr>

  				<tr>
  					<td>Product Price</td>
  					<td><input type="text" class="form-control" name="price" placeholder="Enter Price"></td>
  				</tr>  				
				
  				<tr>
  					<td>Product Category</td>
  					<td><input type="text" class="form-control" name="pcomp" placeholder="Enter Company"></td>
  				</tr>
				<tr>
  					
  					<td colspan="2" align="center"><input type="submit" class="btn btn-primary" name="insertproduct" value="Store" ></td>
  				</tr>
  			</table>
  		</form>
  	</div>
  	</div>
  	<div class="col-md-3"></div>
  </div>

  </div>
  <?php
  if(isset($_GET['insertproduct']))
{
	$name=$_GET['pname'];
$cat=$_GET['pcat'];
$price=$_GET['price'];
$company=$_GET['pcomp'];
//$images=$_GET['img'];

$sql=mysqli_query($dbconnect,"INSERT INTO `product_info` (`Pro_id`, `Pro_name`, `Pro_category`, `Pro_price`, `Pro_company`) VALUES (NULL, '$name', '$cat', '$price', '$company', )");

}

  //SHOW COLUMNS FROM order_info****************************************************************************************
$result = mysqli_query($dbconnect,"SHOW COLUMNS FROM order_info"); 
$res = mysqli_query($dbconnect,"SELECT Order_id FROM order_info"); 
echo "<div class='block2'>";
echo "<form action='' method='GET'>";
    
//VERY IMPORTANT LOGIC FOR APPLING SELECT TAG IN FETCHED DATA ***********************

  
  ?>
  
  <div class="container">
  	<div class="row">
  		<div class="col-md-2"></div>
  		<div class="col-md-8">
  			<table class="table table-bordered">
  			<tr>
  				
  				<th>Select Column</th>
  				<th>Select Order_id</th>
				<th>Enter Updating Data</th>
  				<th>&nbsp;</th>
  				
  			</tr>
  			<tr>
  				<td>
				
<?php echo "<select name='col'>";
echo '<option disabled selected value>Select Column</option>';
while($row = mysqli_fetch_assoc($result))
{
echo "<option value=".$row['Field']." >".$row['Field']."</option>";
}
echo "</select>";

 ?> </td>
	<td>
	<?php echo "<select name='colid' >";
echo '<option disabled selected value>Select ID</option>';
while($ro = mysqli_fetch_assoc($res))
{
echo "<option value=".$ro['Order_id']." >".$ro['Order_id']."</option>";
}
echo "</select>";
 ?>
 
 </td>
  				<td><b> <input type='text' name='NewValue' placeholder='Updating Value'>
    </b></td>
  				<td> <input type='submit' name='submit' VALUE='UPDATE'> </td>
  				
  			</tr>
  				
  			</table>
  		</div>
  		<div class="col-md-2"></div>
  	</div>
  </div>

   </form>
<?php

if(isset($_GET['submit']))
{
	$inputValue=$_GET['NewValue'];
	$inputcol=$_GET['col'];
     $inputid=$_GET['colid'];
	mysqli_query($dbconnect,"UPDATE order_info SET $inputcol = '$inputValue' WHERE Order_id = '$inputid'");
}

?>
   
    <script src="js/jquery-1.12.0.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>
