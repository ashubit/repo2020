<div class="search"><form method="GET" action="view_sales.php">
<input type="text" name="name" placeholder="Medicine">
<input type="submit" name="flow" VALUE="Show">
</form></div>
<?php
include_once("connection.php");
$out="";
$mediname="";
if(isset($_GET['flow']))
{
	$product=$_GET['name'];
	$result=array();
   // var_dump($product);
    $sql=mysqli_query($dbconnect,"SELECT Pro_name,Pro_quantity,Total_amount FROM sales_report ");
if(!$sql)
 {
  echo("Error description: ".mysqli_error($dbconnect));
  }

while($sqlfetch=mysqli_fetch_assoc($sql))
{
	$result[]=$sqlfetch;
}
$total='0';
echo '<table cellpadding=10 RULES="GROUPS"  FRAME="BOX"><thead>';
echo '<tr><th>Medicine</th><th>Quantity</th><th>Total Amount</th></thead><tbody>';
foreach($result as $report)
{

if($report['Pro_name'] == $product)
{
	$mediname=$report['Pro_name'];
	
	echo "<tr><td>".$mediname."</td>";
	$total+=$report['Total_amount'];
	echo "<td>".$report['Pro_quantity']."</td><td>".$report['Total_amount']."</td></tr>";
}
echo '</tbody>';
}
echo '<tfoot><tr><td align="center" colspan=2>';
echo "Total Amount</td> <td> ₹ ".$total."</td></tr>";
echo '</tfoot></table>';
}


?>