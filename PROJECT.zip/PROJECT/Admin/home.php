<?php

include_once("connection.php");

session_start();

if(!isset($_SESSION['Admin_id']))
{
  header("Location:index.php");
}

?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
<title>Pharma Store</title>
<meta charset="iso-8859-1">
<link rel="stylesheet" href="css/layout.css" type="text/css">
<link href="css/bootstrap.min.css" rel="stylesheet">

<!--[if lt IE 9]><script src="scripts/html5shiv.js"></script><![endif]-->
</head>
<body>
<div class="wrapper row1">
  <header id="header" class="clear">
    <div id="hgroup">
      <h1><a href="#">Pharma Store</a></h1>
      <h2>Medicine at you'r door Step</h2>
    </div>
  <!-- This form is for Searching only************************************************************** -->
    <form action="<?php $_SERVER['PHP_SELF']?>" method="POST">
      <fieldset>
        <legend>Search:</legend>
        <input type="text" value="Search Our Website&hellip;" >
        <input type="submit" id="sf_submit" value="Search">
      </fieldset>
    </form>
  <!-- Over searching form ************************************************************************** -->
    <nav>
      <ul>
        <li><a href="home.html">Home</a></li>
        <li><a href="profile.php">Profile</a></li>
        <li><a href="order.php">Place Page</a></li>
        <li><a href="update_pro.php">CRUD Operations</a></li>   
        <li><a href="search.php">Search</a></li>
       </ul>
    </nav>
  </header>
</div>
<!-- content -->
<div class="wrapper row2">
  <div id="container" class="clear">
    <!-- ***************************************   Slider   ************************************************ -->
    <section id="slider" class="clear">
      <figure><img src="images/l1.gif" alt="Sliding IMG">
        <figcaption>
          <h2>Medicine Store</h2>
          <p>Nullamlacus dui ipsum conseque loborttis non euisque morbi penas dapibulum orna. Urnaultrices quis curabitur phasellentesque congue magnis vestibulum quismodo nulla et feugiat adipiscinia pellentum leo.</p>
          <footer class="more"><a href="#">Read More &raquo;</a></footer>
        </figcaption>
      </figure>
    </section>
  <!-- ***************************************   Slider   ***************************************** -->
    <!-- main content -->
    <div id="intro">
      <section class="clear">
        <!-- article 1 -->
        <article class="two_quarter">
          <h2>Lorum ipsum dolor</h2>
          <p>This is a W3C compliant free website  from <a href="http://www.os-templates.com/" title="Free Website Templates">OS Templates</a>. For full terms of use of this template please read our <a href="http://www.os-templates.com/template-terms">website template licence</a>.</p>
          <p>You can use and modify the template for both personal and commercial use. You must keep all copyright information and credit links in the template and associated files. For more HTML5 templates visit <a href="http://www.os-templates.com/">free website templates</a>.</p>
        </article>
        <!-- article 2 -->
        <article class="two_quarter lastbox">
          <figure>
            <ul class="clear">
              <li><a href="#"><img src="images/s1.gif" width="130" height="130" alt=""></a></li>
              <li><a href="#"><img src="images/s2.gif" width="130" height="130" alt=""></a></li>
              <li class="last"><a href="#"><img src="images/s3.gif" width="130" height="130" alt=""></a></li>
            </ul>
            <figcaption><a href="#">View Our Image Gallery Here &raquo;</a></figcaption>
          </figure>
        </article>
      </section>
    </div>
    <!-- ########################################################################################## -->
    <!-- ########################################################################################## -->
    <!-- ########################################################################################## -->
    <!-- ########################################################################################## -->
    <div id="homepage" class="last clear">

    <div class="panel panel-info" style="margin-right:auto;position: relative;">
<div class="panel-heading"><h3 class="panel-title">Medicine List</h3></div>
<div class="panel-body">
      
<?php

$query1 = mysqli_query($dbconnect,"SELECT Pro_name,Pro_price  FROM product_info "); 

if (isset($query1)){
while ($row = mysqli_fetch_assoc($query1))
  {

  echo '<input type="text" class="form-control" value='.$row['Pro_name'].' disabled><input type="text" class="form-control" ₹ value='.$row['Pro_price'].' disable> <br>';
  }
}
else
{
echo 'err404';
}


?>


<!------------------------------------------------------------------------------- -->
<div class="panel-footer"></div>
</div>
</div>
<div class="col-lg-4">
</div>
</div>
</div>

 
  </body>
</html>

    </div>
    <!-- / content body -->
  </div>
</div>
<!-- Footer -->
<div class="wrapper row3">
  <footer id="footer" class="clear">
    <p class="fl_left">Copyright &copy; 2012 - All Rights Reserved - <a href="#">Domain Name</a></p>
    <p class="fl_right">Template by <a href="#" title="Free Website ">WEBSITE</a></p>
  </footer>
</div>
</body>
</html>
