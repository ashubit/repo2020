<?php
include_once("connection.php");
session_start();

if (isset($_POST['submit']))
{
	if(isset($_POST['mail']))
{
	
	
	$email = strip_tags($_POST['mail']);
	$pass = strip_tags($_POST['passcode']);
	
	$email = mysqli_real_escape_string($dbconnect, $email);
	$pass = mysqli_real_escape_string($dbconnect, $pass);
	
	//$pass = md5($pass);
	
	$sql = "SELECT Admin_id,Admin_email,Admin_name,Admin_pwd,Admin_phone FROM admin_info WHERE Admin_email = '$email' ";

	$query = mysqli_query($dbconnect , $sql);
	$row = mysqli_fetch_assoc($query);
	$aid = $row['Admin_id'];
	$dbmail = $row['Admin_email'];
	$dbpass = $row['Admin_pwd'];
	
	if($email == $dbmail && $pass == $dbpass )
	{
		//$_SESSION['uname'] = $uname ;
		$_SESSION['Admin_id'] = $aid;
		header("Location:home.php");
	}
	else {
		echo "<h2> F@U you </br> Don't Mess with me.</h2>";
		
	}
	}
	}
	else{
		echo'Error to execute if condetion with "email" ';
	}
	
	?>
	