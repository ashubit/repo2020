<?php 
$hostname="localhost";
$username="root";
$password="";
$database="bca";
$dbconnect = mysqli_connect($hostname,$username,$password,$database) or die("Error in connection with database ...");


?>