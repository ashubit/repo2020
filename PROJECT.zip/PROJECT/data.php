<?php
include_once("connection.php");
session_start();

if (isset($_POST['submit']))
{
	if(isset($_POST['email']))
{
	
	
	$email = strip_tags($_POST['email']);
	$pass = strip_tags($_POST['password']);
	
	$uname = mysqli_real_escape_string($dbconnect, $email);
	$pass = mysqli_real_escape_string($dbconnect, $pass);
	
	//$pass = md5($pass);
	
	$sql = "SELECT Cust_id,email,password,uname FROM members WHERE email = '$email' AND activated ='1' LIMIT 1";

	$query = mysqli_query($dbconnect , $sql);
	$row = mysqli_fetch_assoc($query);
	$uid = $row['Cust_id'];
	$dbname = $row['uname'];
	$dbpass = $row['password'];
	
	if($uname = $dbname && $pass == $dbpass )
	{
		//$_SESSION['uname'] = $uname ;
		$_SESSION['Cust_id'] = $uid;
		header("Location:home.php");
	}
	else {
		echo "<h2> F@U you </br> Don't Mess with me.</h2>";
		
	}
	}
	}
	else{
		echo'Error to execute if condetion with "email" ';
	}
	
	?>
	