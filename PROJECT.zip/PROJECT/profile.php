<?php

include_once("connection.php");

session_start();

if(!isset($_SESSION['Cust_id']))
{
  header("Location:index.php");
}

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="images/favicon.ico">

    <title>Profile</title>

   <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/profile.css">
    -->
  </head>
<body role="document">

    <!-- Fixed navbar -->
    <nav class="navbar navbar-inverse navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
<h1><a href="#">Pharma Store</a></h1>
      <h6>Medicine at you'r door Step</h6>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li class="active"><a href="home.php">Home</a></li>
              <li><a href="order.php">Place order</a></li>
              <li><a href="update_profile01.php">Edit Profile</a></li>
               <li><a href="logout.php">Logout</a></li>
            <li><a href="about.php">About</a></li>

              </ul>
            </li>
             </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>
<div class="container" style="margin-top:100px; " >
<div class="col-lg-8">
<div class="panel panel-info" style="margin-left:250px; margin-right:auto;">
<div class="panel-heading"><h3 class="panel-title">User Registration</h3></div>
<div class="panel-body">

<?php

$sess=$_SESSION['Cust_id'];

$sql = "SELECT Cust_id,fname,lname,uname,gender,password,email,contact,address FROM members WHERE Cust_id = '$sess' " ;

	$query = mysqli_query($dbconnect , $sql);
	$row = mysqli_fetch_assoc($query);
     $uid = $row['Cust_id'];
     $fname=$row['fname'];
     $lname=$row['lname'];
     $uname=$row['uname'];
     $gender=$row['gender'];
     $password=$row['password'];
     $email=$row['email'];
     $contact=$row['contact'];
     $address=$row['address'];



	echo '<div class="con" >ID</div>  <div class="data" > '.$uid.'</div>';
echo '<div class="con">First Name</div>  <div class="data"> '.$fname.'</div>';
echo '<div class="con">Last Name</div>  <div class="data"> '.$lname.'</div>';
echo '<div class="con">User Name</div>  <div class="data"> '.$uname.'</div>';
echo '<div class="con">Gender</div>  <div class="data"> '.$gender.'</div>';
echo '<div class="con">E-mail</div>  <div class="data"> '.$email.'</div>';
echo '<div class="con">Contact</div>  <div class="data"> '.$contact.'</div>';
echo '<div class="con">Address</div>  <div class="data"> '.$address.'</div>';
	
	
	
?>

<div class="panel-footer"></div>
</div>
</div>
<div class="col-lg-4">
</div>
</div>
</div>
  </body>
</html>