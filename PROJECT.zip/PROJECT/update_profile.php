<?php

session_start();

if(!isset($_SESSION['Cust_id']))
{
	header("Location:index.php");
}

include_once("connection.php");

?>

<HTML>


<div class="edit">
<form  method="GET" action=" <?php $_SERVER['PHP_SELF']; ?> ">
<div class="contant">First Name</div>
<input type="text" name="data1" value="VALUE">
<input type="submit"  VALUE="EDIT" > 
</form> 

<?php 

$c_id=$_SESSION['Cust_id'];



if(isset($_GET['data1'])){
	$temp1 = $_GET['data1'];
mysqli_query($dbconnect,"UPDATE members SET fname = '$temp1' WHERE Cust_id = '$c_id' "); }




?>
</div>
<!---------------------------------------------------------->

<div class="edit">
<form  method="GET" action=" <?php $_SERVER['PHP_SELF']; ?> ">
<div class="contant">Last Name</div>
<input type="text" name="data2" value="VALUE">
<input type="submit"  VALUE="EDIT" > 
</form> 

<?php if(isset($_GET['data2'])){
	$temp2 = $_GET['data2'];
mysqli_query($dbconnect,"UPDATE members SET fname = '$temp2' WHERE Cust_id = '$c_id' ");} 
?>
</div>
<!---------------------------------------------------------->

<div class="edit">
<form  method="GET" action=" <?php $_SERVER['PHP_SELF']; ?> ">
<div class="contant">User Name</div>
<input type="text" name="data3" value="VALUE">
<input type="submit"  VALUE="EDIT" > 
</form> 

<?php 
if(isset($_GET['data3'])){
	$temp3 = $_GET['data3'];
mysqli_query($dbconnect,"UPDATE members SET uname = '$temp3' WHERE Cust_id = '$c_id' ");} 
?>
</div>
<!---------------------------------------------------------->

<div class="edit">
<form  method="GET" action=" <?php $_SERVER['PHP_SELF']; ?> ">
<div class="contant">Password</div>
<input type="text" name="data4" value="VALUE">
<input type="submit"  VALUE="EDIT" > 
</form> 

<?php 
if(isset($_GET['data4'])){
	$temp4 = $_GET['data4'];
	mysqli_query($dbconnect,"UPDATE members SET password = '$temp4' WHERE Cust_id = '$c_id' "); }
?>
</div>
<!---------------------------------------------------------->

<div class="edit">
<form  method="GET" action=" <?php $_SERVER['PHP_SELF']; ?> ">
<div class="contant">E-mail</div>
<input type="text" name="data5" value="VALUE">
<input type="submit"  VALUE="EDIT" > 
</form> 

<?php 
if(isset($_GET['data5'])){
	$temp5 = $_GET['data5'];
mysqli_query($dbconnect,"UPDATE members SET email = '$temp5' WHERE Cust_id = '$c_id' ");} 
?>
</div>
<!---------------------------------------------------------->

<div class="edit">
<form  method="GET" action=" <?php $_SERVER['PHP_SELF']; ?> ">
<div class="contant">Contact No.</div>
<input type="text" name="data6" value="VALUE">
<input type="submit"  VALUE="EDIT" > 
</form> 

<?php 
if(isset($_GET['data6'])){
	$temp6 = $_GET['data6'];
mysqli_query($dbconnect,"UPDATE members SET contact = '$temp6' WHERE Cust_id = '$c_id' ");} 
?>
</div>
<!---------------------------------------------------------->

<div class="edit">
<form  method="GET" action=" <?php $_SERVER['PHP_SELF']; ?> ">
<div class="contant">Address</div>
<input type="text" name="data7" value="VALUE">
<input type="submit"  VALUE="EDIT" > 
</form> 

<?php 
if(isset($_GET['data7'])){
	$temp7 = $_GET['data7'];
mysqli_query($dbconnect,"UPDATE members SET address = '$temp7' WHERE Cust_id = '$c_id' ");} 
?>
</div>
<!---------------------------------------------------------->

</HTML>